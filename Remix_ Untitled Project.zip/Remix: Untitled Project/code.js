var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var boundary1 = createSprite(190,120,420,3)
var boundary2 = createSprite(190,260,420,3);

var player = createSprite(20,180,20,20);
player.shapeColor="green";
var obstacle1 = createSprite(120,140,15,15);
obstacle1.shapeColor = "red";

var obstacle2 = createSprite(220,230,15,15);
obstacle2.shapeColor="red";

var obstacle3 = createSprite(320,140,15,15);
obstacle3.shapeColor ="red";

var target = createSprite(360,180,20,120);
function draw() {
  background("white")
 if (keyDown("left")) {
player.x=player.x-5;
  }
  if (keyDown("right")) {
  player.x=player.x+5  
  }
  
  
  createEdgeSprites(edges) 
  obstacle1.bounceOff(boundary1)
  obstacle2.bounceOff(boundary1)
  obstacle3.bounceOff(boundary1)
  obstacle1.bounceOff(boundary2)
  obstacle2.bounceOff(boundary2)
  obstacle3.bounceOff(boundary2)
  
 if (player.isTouching(obstacle1)) {
    player.x=20
    player.y=180
  }
  if (player.isTouching(obstacle2)) {
    player.x=20
    player.y=180
  } 
  if (player.isTouching(obstacle3)) {
    player.x=20
    player.y=180
  }
  if (player.isTouching(target)) {
    textSize(50)
    fill("blue")
    text("You won",100,200)
  }
  
  
  
  
  
  
  
  drawSprites();
  
}
  obstacle1.velocityY=7
  obstacle2.velocityY=7
  obstacle3.velocityY=7
   
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
